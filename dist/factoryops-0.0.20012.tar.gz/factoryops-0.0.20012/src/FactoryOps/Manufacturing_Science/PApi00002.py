from FactoryOps.Manufacturing_Science.littleslaw.Py00001 import LittlesLaw

__all__ = [
    "LittlesLaw"
]