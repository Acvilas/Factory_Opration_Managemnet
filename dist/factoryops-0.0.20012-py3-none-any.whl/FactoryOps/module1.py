def greet(name):
    """Returns a greeting message."""
    return f"Hello, {name}!"