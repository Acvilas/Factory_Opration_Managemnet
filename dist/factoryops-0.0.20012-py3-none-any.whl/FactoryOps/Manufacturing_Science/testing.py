def greet1(name):
    """Returns a greeting message."""
    return f"Hello 1, {name}!"

